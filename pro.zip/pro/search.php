<?php
require "server/functions.php";
$e = $_REQUEST["e"];
$sel_product = "select * from products where pro_keywords like '%$e%'";
$run_pro  = mysqli_query($con,$sel_product);
$count = mysqli_num_rows($run_pro);

if($count>0)
{